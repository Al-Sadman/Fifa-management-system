// {
//     user_id: '',
//     email: '',
//     password: '',
//     user_name: '',
//     bank_name: '',
//     transaction_code: '',
//     account_no: '',
//     status: false,
// },
// user schema
const Query =
{
    deletePlayer: function(id)
    {
        return `DELETE FROM players WHERE player_id='${id}'`;
    },
    deleteSquad: function(id)
    {
        return `DELETE FROM squads WHERE ID='${id}'`;
    },
    addPlayer: function addPlayer(player_id, playerName, position, nation, club, league,
        season, weight, height, strong_foot, weak_foot, SM, SB, ST, pace, shooting, pass, agility, defence,
        physical, reflexes, diving, positioning, handling, kicking) {
        let x =
            `INSERT INTO players(
            player_id,
            player_name, 
            position, 
            nation, 
            club, 
            league,
            season, 
            weight, 
            height, 
            strong_foot, 
            weak_foot, 
            skill_move, 
            Skill_boost, 
            special_trait, 
            pace, 
            shooting, 
            pass, 
            agility, 
            defence,
            physical,
            reflexes, 
            diving, 
            positioning, 
            handling, 
            kicking)  
            VALUES 
            (
            '${player_id}',
            '${playerName}',
            '${position}',
            '${nation}',
            '${club}',
            '${league}',
             ${season},
             ${weight},
            '${height}',
            '${strong_foot}', 
            '${weak_foot}',
            '${SM}',
            '${SB}',
            '${ST}',
             ${pace},
             ${shooting},
             ${pass},
             ${agility},
             ${defence},
             ${physical},
             ${reflexes},
             ${diving},
             ${positioning},
             ${handling},
             ${kicking});`

        console.log(height);
        console.log(x);

        return x;
    },
    addSquad: function addSquad(ID, squad){
        return  `INSERT INTO squads(ID, squad) VALUES ('${ID}', ${squad});`
    },
    addUser: function addUser(user_name, email, password, user_id, bank_name, transaction_code, account_no) {
        return (
            `INSERT INTO users(user_name, email, password, user_id, bank_name, transaction_code, account_no) VALUES ('${user_name}','${email}','${password}','${user_id}',${bank_name},${transaction_code},${account_no});;`
        );
    },
    getPlayers: function getPlayers() {
        return (
            `SELECT * FROM players;`
        );
    },
    getSquads: function getSquads() {
        return (
            `SELECT * FROM squads;`
        );
    },
    getUsers: function getUsers() {
        return (
            `SELECT * FROM users;`
        );
    },
    getUser: function getUser(email) {
        return (
            `SELECT * FROM users where email='${email}';`
        );
    },


    createPlayersTable:
        `CREATE TABLE players(player_id varchar(255), player_name varchar(255), position varchar(255), 
        nation varchar(255), club varchar(255), league varchar(255),
        season INT, weight INT, height varchar(255), strong_foot varchar(255), weak_foot varchar(255), 
        skill_move varchar(255), Skill_boost varchar(255), special_trait varchar(255), 
        pace INT, shooting INT, pass INT, agility INT, defence INT,
        physical INT, reflexes INT, diving INT, positioning INT, handling INT, kicking INT, PRIMARY KEY (player_id));`,

    createUsersTable:
        "CREATE TABLE users(user_name varchar(255) NOT NULL,email varchar(255) NOT NULL,password varchar(255) NOT NULL,user_id varchar(255) NOT NULL, bank_name varchar(255), transaction_code varchar(255), account_no varchar(255), PRIMARY KEY (user_id));",
}
export default Query; 