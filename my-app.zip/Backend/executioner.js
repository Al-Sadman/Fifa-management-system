import axios from 'axios';

async function executioner(Query, type) {
    let URL = `http://localhost/fifa_db_manager.php?QUERY=${Query}&&TYPE=${type}`;
    // this url goes to the php file with the given query and query type
    let result = await axios.post(URL, {}, {
        headers: {
            'Content-Type': 'application/json;charset=UTF-8',
            "Access-Control-Allow-Origin": "*",
        }
    });
    console.log(result);
    return result;
}
export default executioner;