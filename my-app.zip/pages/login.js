import React from 'react'
import { useRouter } from 'next/router'
import styles from '../styles/Login.module.css'
import { useState } from 'react';
import executioner from '../Backend/executioner';
import Query from '../Backend/Queries';
import {v4 as uuid} from 'uuid';

export default function Login() {

    const Router = useRouter();
    const PAGETYPES = {
        LOGIN: 'LOGIN',
        REGISTER: 'REGISTER',
    }
    const RESGISTER_TYPES =
    {
        STAGE1: 'STAGE1',
        STAGE2: 'STAGE2',
    }

    const [pageType, setPageType] = useState(PAGETYPES.LOGIN);
    const [resgisterType, setRegisterType] = useState(RESGISTER_TYPES.STAGE1);


    const [userEmail, setUserEmail] = useState("");
    const [signupUserName, setSignupUserName] = useState("");
    const [signupEmail, setSignupEmail] = useState("");
    const [password, setPassword] = useState("");
    const [signupPassword, setSignupPassword] = useState("");
    const [signupPasswordConfirmation, setSignupPasswordConfirmation] = useState("");









    return (
        <div className={styles.container}>
            <div className={styles.icon_container}>
                <h1>Fifa Buddy</h1>
            </div>
            {
                (pageType === PAGETYPES.LOGIN) &&
                <div className={styles.login_box}>
                    <div className={styles.login_box_greeting_container}>
                        SIGN IN
                    </div>
                    <div className={styles.login_box_email_container}>
                        <div className={styles.login_input_prompt}>
                            Email
                        </div>

                        <div className={styles.login_input_container}>
                            <input
                                type="text"
                                placeholder="Email"
                                spellCheck="false"
                                value={userEmail}
                                onChange={(e) => { setUserEmail(e.target.value) }} 
                            />
                        </div>
                    </div>
                    <div className={styles.login_box_password_container}>
                        <div className={styles.login_input_prompt}>
                            Password
                        </div>
                        <div className={styles.login_input_container}>
                            <input type="password"
                                placeholder="Password" spellCheck="false"
                                autoComplete="new-password"
                                onChange={(e) => { setPassword(e.target.value) }} 
                            />
                        </div>
                    </div>

                    <div className={styles.login_button_container}>
                        <div className={styles.login_button} onClick={async () => {
                            let user = await (await executioner(Query.getUser(userEmail), "RETRIEVE")).data.data[0];
                            if(password !== user.password) return;
                            if (userEmail==='admin') Router.push('/admin');
                            else
                                Router.push('/home');
                        }}>
                            Login
                        </div>
                    </div>
                    <div className={styles.login_box_signup_prompt_container}>
                        <div className={styles.login_box_signup_prompt}>
                            Don't have an account?
                        </div>
                        <div className={styles.login_box_signup_button} onClick={() => {
                            setRegisterType(RESGISTER_TYPES.STAGE1);
                            setPageType(PAGETYPES.REGISTER);
                        }}>
                            Create account
                        </div>
                    </div>
                </div>

            }
            {
                pageType === PAGETYPES.REGISTER &&
                <div className={styles.register_box}>
                    <div className={styles.login_box_greeting_container}>
                        REGISTER
                    </div>

                    {
                        (resgisterType === RESGISTER_TYPES.STAGE1) &&

                        <div className={styles.login_box_email_container}>
                            <div className={styles.login_input_prompt}>
                                Name
                            </div>
                            <div className={styles.login_input_container}>
                                <input
                                    type="text"
                                    placeholder="Name"
                                    spellCheck="false"
                                    onChange={(username) => { setSignupUserName(username.target.value) }}
                                />
                            </div>
                        </div>
                    }

                    {
                        (resgisterType === RESGISTER_TYPES.STAGE1) &&
                        <div className={styles.login_box_email_container}>
                            <div className={styles.login_input_prompt}>
                                Email
                            </div>
                            <div className={styles.login_input_container}>
                                <input
                                    type="text"
                                    placeholder="Email"
                                    spellCheck="false"
                                    onChange={(useremail) => { setSignupEmail(useremail.target.value) }}
                                />
                            </div>
                        </div>
                    }




                    {
                        (resgisterType === RESGISTER_TYPES.STAGE2) &&
                        <div className={styles.login_box_password_container}>
                            <div className={styles.login_input_prompt}>
                                Password
                            </div>
                            <div className={styles.login_input_container}>
                                <input type="password"
                                    placeholder="Password" spellCheck="false"
                                    autoComplete="new-password"
                                    onChange={(password) => { setSignupPassword(password.target.value) }}

                                />
                            </div>
                        </div>
                    }


                    {
                        (resgisterType === RESGISTER_TYPES.STAGE2) &&

                        <div className={styles.login_box_password_container}>
                            <div className={styles.login_input_prompt}>
                                confirm password
                            </div>
                            <div className={styles.login_input_container}>
                                <input type="password"
                                    placeholder="confirm password" spellCheck="false"
                                    autoComplete="new-password"
                                    onChange={(confirm_password) => { setSignupPasswordConfirmation(confirm_password.target.value) }}
                                />
                            </div>
                        </div>

                    }


                    <div className={styles.login_box_signup_prompt_container}>
                        <div className={styles.login_box_signup_prompt}>
                            Already have an account?
                        </div>
                        <div className={styles.login_box_signup_button} onClick={() => { setPageType(PAGETYPES.LOGIN) }}>
                            Sign in
                        </div>
                    </div>

                    <div className={styles.login_button_container}>
                        <div className={styles.login_button} onClick={async () => {

                            if (resgisterType === RESGISTER_TYPES.STAGE1)
                                setRegisterType(RESGISTER_TYPES.STAGE2);
                            else if (resgisterType === RESGISTER_TYPES.STAGE2) {
                                console.log(signupEmail);
                                // "localhost/db_manger.php&&QUERY=" + INSERT INTO users(user_name, email, password, user_id, bank_name, transaction_code, account_no) VALUES ('${user_name}','${email}','${password}','${user_id}',${bank_name},${transaction_code},${account_no});;` && TYPE=send
                                await executioner(Query.addUser(signupUserName, signupEmail, signupPassword, uuid(), null, null, null), "SEND");
                                setRegisterType(RESGISTER_TYPES.STAGE1);
                                setPageType(PAGETYPES.LOGIN);
                            }


                        }} >
                            {
                                (resgisterType === RESGISTER_TYPES.STAGE2) ?
                                    "Sign Up" :
                                    "Next"
                            }
                        </div>
                    </div>
                </div>
            }

            <div className={styles.tag_container}>
                <div className={styles.tagline}>
                    A site that renders Football Card.
                </div>
                <div className={styles.learn_more_link} onClick={() => { Router.push('learn-more') }}>
                    Learn More
                </div>
            </div>

        </div>
    )
}