import Head from 'next/head'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import styles from '../styles/Home.module.css'
import database from './database'


const filter = () => {
    const router = useRouter();
    const [showSeason, setShowSeason] = useState(false);
    const [text, setText] = useState("");
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState([]);

    const [isGoalKeeper, setIsGoalKeeper] = useState(false);



    useEffect(() => {
        setAllPlayers(database.players);
        setFilteredPlayers(database.players);
    }, [])

    function getAverage(player) {
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + player.pace;
            summation = summation + player.shooting;
            summation = summation + player.pass;
            summation = summation + player.agility;
            summation = summation + player.defence;
            summation = summation + player.physical;

        }
        else {
            summation = summation + player.physical;
            summation = summation + player.reflexes;
            summation = summation + player.diving;
            summation = summation + player.positioning;
            summation = summation + player.handling;
            summation = summation + player.kicking;
        }
        return summation / 6.0;
    }

    let handleSearch = (event) => {
        let keyword = event?.target?.value;
        setText(keyword);
        let result = [];
        for (let i = 0; i < allPlayers.length; i++) {
            if (allPlayers[i].player_name.toLowerCase().includes(keyword.toLowerCase()))
                result = [...result, allPlayers[i]];
        }
        setFilteredPlayers(result);
    }



    return (
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>

                    <div className={styles.navbottom_link} onClick={() => { router.push('/link') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/link') }}>
                        compare
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/link') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>
            {
                !showSeason &&
                <div className={styles.search_container}>
                    <input type="text" placeholder="search player"
                        onChange={(e) => { handleSearch(e) }} />
                </div>

            }
            {
                !showSeason &&
                <div className={styles.search_results}>
                    {
                        filteredPlayers.map((current, index) =>
                            <div key={current.player_name} className={styles.search_result} onClick={() => { router.push(`/player-card/${current.player_id}`) }}>
                                <div className={styles.result_part}>
                                    <div className={styles.rating}>{getAverage(current).toFixed(0)}</div>
                                    <div className={styles.player_name}> {current.player_name} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.league}> {current.league} </div>
                                    <div className={styles.club}> {current.club} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.nation}> {current.nation} </div>
                                </div>
                            </div>
                        )
                    }
                </div>

            }
        </div>
    )
}

export default filter