import Head from 'next/head'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import executioner from '../Backend/executioner'
import Query from '../Backend/Queries'
import styles from '../styles/Home.module.css'
import database from './database'


export default function Home() {
    const router = useRouter();
    const [showSeason, setShowSeason] = useState(false);
    const [text, setText] = useState("");
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState([]);
    const [squads, setSquads] = useState([]);

    const [isGoalKeeper, setIsGoalKeeper] = useState(false);



    useEffect(() => {

        async function run() {
            let squads_DB;
            squads_DB = (await executioner(Query.getSquads(), "RETRIEVE"))?.data.data;
            console.log(squads_DB);
            let result = [];
            for (let i = 0; i < squads_DB.length; i++) {
                // console.log();
                let squad =  JSON.parse(squads_DB[i].squad);
                 result = [...result, squad];
            }
            console.log(result);
            setSquads(result);
        }
        run();

    }, [])


    return (
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>


                    <div className={styles.navbottom_link} onClick={() => { router.push('/squad') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/compare') }}>
                        compare
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>
            {
                <div className={styles.squads}>
                    {

                        squads.map((current, index) =>
                        <>
                            <div className={styles.squad} onClick={()=>{
                                router.push(`squads/${current.id}`)
                            }}>
                                {current.name}
                            </div>
                           
                        </>
                        )
                    }

                </div>
            }
        </div>

    )
}
