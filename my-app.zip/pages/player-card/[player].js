import React from 'react'
import styles from '../../styles/Player.module.css'
import ProgressBar from 'react-percent-bar';
import { useRouter } from 'next/router'
import database from '../database'
import executioner from '../../Backend/executioner';
import Query from '../../Backend/Queries';


const player = ({ player_info }) => {
    const router = useRouter();
    function getAverage(player) {
        if (!player) return;
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }

    return (


        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>


                    <div className={styles.navbottom_link} onClick={() => { router.push('/squad') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/compare') }}>
                        compare
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/draft') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>


            <div className={styles.main}>
                <div className={styles.player_name}>
                    <p>
                        {player_info?.player_name + " (" + player_info?.position + ")"}
                    </p>
                </div>
                <div className={styles.main_three}>
                    <p>
                        club : {" " + player_info?.club}
                    </p>
                    <p>
                        nation : {" " + player_info?.nation}
                    </p>
                    <p>
                        league : {" " + player_info?.league}
                    </p>
                </div>
                {
                    (player_info.position !== 'gk') &&

                    <div className={styles.points}>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"pace : " + player_info.pace}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.pace} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"shooting : " + player_info.shooting}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.shooting} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"pass : " + player_info.pass}

                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.pass} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"agility : " + player_info.agility}

                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.agility} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"defence : " + player_info.defence}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.defence} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"physical : " + player_info.physical}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.physical} />
                            </div>
                        </div>

                    </div>
                }



                {
                    (player_info.position === 'gk') &&

                    <div className={styles.points}>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"reflexes : " + player_info.reflexes}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.reflexes} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"diving : " + player_info.diving}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.diving} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"positioning : " + player_info.positioning}

                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.positioning} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"handling : " + player_info.handling}

                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.handling} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"kicking : " + player_info.kicking}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.kicking} />
                            </div>
                        </div>

                        <div className={styles.point_holder}>
                            <div className={styles.point_name}>
                                {"physical : " + player_info.physical}
                            </div>
                            <div className={styles.point_bar}>
                                <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.physical} />
                            </div>
                        </div>

                    </div>
                }


                <div className={styles.main_three}>
                    <p>
                        height : {" " + player_info?.height}
                    </p>
                    <p>
                        weight : {" " + player_info?.weight}
                    </p>
                    <p>
                        weak foot : {" " + player_info?.weak_foot}
                    </p>
                    <p>
                        strong foot : {" " + player_info?.strong_foot}
                    </p>
                </div>

                <div className={styles.main_three}>
                    <p>
                        skill move : {" " + player_info?.skill_move}
                    </p>
                    <p>
                        skill boost : {" " + player_info?.skill_boost}
                    </p>
                    <p>
                        special trait : {" " + player_info?.special_trait}
                    </p>
                </div>







            </div>
        </div>

    )
}


// gets the props for the current slug
export const getServerSideProps = async pageContext => {
    const notApplicable =
    {
        notFound: true
    }
    const player = pageContext.query.player;
    console.log(player);
    if (!player) {
        return notApplicable;
    }
    else {
        let players;
        players = await executioner(Query.getPlayers(), "RETRIEVE");
        let player_info = players.data.data.find(current => current.player_id === player);
        console.log(database);
        return { props: { player_info } };
    }
};

export default player