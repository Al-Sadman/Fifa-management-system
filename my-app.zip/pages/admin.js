import React, { useState, useEffect } from 'react'
import styles from '../styles/Admin.module.css'
import database from './database'
import { useRouter } from 'next/router'
import { v4 as uuid } from 'uuid'
import executioner from '../Backend/executioner'
import Query from '../Backend/Queries'



const Admin = () => {

    const router = useRouter();
    const STAGE =
    {
        STAGE1: 'STAGE1',
        STAGE2: 'STAGE2',
        STAGE3: 'STAGE3'
    }

    const [isGoalKeeper, setIsGoalKeeper] = useState(false);
    const [text, setSearchText] = useState("");
    const [users, setUsers] = useState([]);
    const [stage, setStage] = useState(STAGE.STAGE2);
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState([]);

    // For adding a player
    //

    const [playerName, setPlayerName] = useState("");
    const [nation, setPlayerNation] = useState("");
    const [position, setPosition] = useState("");
    const [season, setPlayerSeason] = useState("");
    const [club, setPlayerClub] = useState("");
    const [league, setPlayerLeague] = useState("");
    const [weight, setPlayerWeight] = useState(0);
    const [height, setPlayerHeight] = useState("");
    const [strong_foot, setPlayerStrongFoot] = useState("");
    const [weak_foot, setPlayerWeakFoot] = useState("");
    const [SM, setSM] = useState("");
    const [SB, setSB] = useState("");
    const [ST, setST] = useState("");
    const [pace, setPace] = useState(0);
    const [shooting, setShooting] = useState(0);
    const [pass, setPass] = useState(0);
    const [agility, setAgility] = useState(0);
    const [reflexes, setReflexes] = useState(0);
    const [positioning, setPositiong] = useState(0);
    const [diving, setDiving] = useState(0);
    const [handling, setHandling] = useState(0);
    const [kicking, setKicking] = useState(0);
    const [physical, setPhysical] = useState(0);
    const [defence, setDefence] = useState(0);


    function getAverage(player) {
        console.log(player.pace);
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }


    // to search player for updating
    let handleSearch = (event) => {
        let keyword = event?.target?.value;
        setSearchText(keyword);
        let result = [];
        for (let i = 0; i < allPlayers.length; i++) {
            if (allPlayers[i].player_name.toLowerCase().includes(keyword.toLowerCase()))
                result = [...result, allPlayers[i]];
        }
        setFilteredPlayers(result);
    }



    function subscribedUsers(users) {
        if (!users) return [];
        var result = [];
        for (let i = 0; i < users.length; i++) {
            if (users[i].bank_name === null)
                result = [...result, users[i]];

        }
        return result;
    }



    useEffect(() => {

        async function run() {
            let response;
            response = await executioner(Query.getUsers(), "RETRIEVE");
            console.log(response.data.data);
            setUsers(subscribedUsers(response.data.data));
            let players;
            players = await executioner(Query.getPlayers(), "RETRIEVE");
            setAllPlayers(players.data?.data);
            setFilteredPlayers(players?.data?.data);
        }
        run();

    }, [])

    return (
        <div className={styles.container}>

            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    Fifa Buddy
                </div>
                <div className={styles.navbottom}>
                    <div className={styles.navbottom_link} onClick={() => { setStage(STAGE.STAGE1) }}>
                        add player
                    </div>

                    <div className={styles.navbottom_link} onClick={() => { setStage(STAGE.STAGE2) }}>
                        update player
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { setStage(STAGE.STAGE3) }}>
                        subscription info
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>

            {
                (stage === STAGE.STAGE1) &&
                <div className={styles.stage}>
                    <div className={styles.add_player}>
                        <div className={styles.input_fields}>


                            <div className={styles.input_field}>
                                <p>
                                    Player Name :
                                </p>
                                <input type="text" placeholder="Player name"
                                    onChange={(e) => { setPlayerName(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    Player position :
                                </p>
                                <input type="text" placeholder="position"
                                    onChange={(e) => { setPosition(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    nation :
                                </p>
                                <input type="text" placeholder="nation"
                                    onChange={(e) => { setPlayerNation(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    club :
                                </p>
                                <input type="text" placeholder="club"
                                    onChange={(e) => { setPlayerClub(e.target.value) }} />
                            </div>

                            <div className={styles.input_field}>
                                <p>
                                    League :
                                </p>
                                <input type="text" placeholder="league"
                                    onChange={(e) => { setPlayerLeague(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    season :
                                </p>
                                <input type="text" placeholder="season"
                                    onChange={(e) => { setPlayerSeason(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    weight :
                                </p>
                                <input type="text" placeholder="weight"
                                    onChange={(e) => { setPlayerWeight(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    height :
                                </p>
                                <input type="text" placeholder="height"
                                    onChange={(e) => { setPlayerHeight(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    strong foot :
                                </p>
                                <input type="text" placeholder="strong foot"
                                    onChange={(e) => { setPlayerStrongFoot(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    weak foot :
                                </p>
                                <input type="text" placeholder="weak foot"
                                    onChange={(e) => { setPlayerWeakFoot(e.target.value) }} />

                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    skill move:
                                </p>
                                <input type="text" placeholder="skill move"
                                    onChange={(e) => { setSM(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    skill boost :
                                </p>
                                <input type="text" placeholder="skill boost"
                                    onChange={(e) => { setSB(e.target.value) }} />
                            </div>
                            <div className={styles.input_field}>
                                <p>
                                    special trait :
                                </p>
                                <input type="text" placeholder="special trait"
                                    onChange={(e) => { setST(e.target.value) }} />
                            </div>

                            {
                                isGoalKeeper &&
                                <>

                                    <div className={styles.input_field}>
                                        <p>
                                            pace :
                                        </p>
                                        <input type="text" placeholder="Pace"
                                            onChange={(e) => { setPace(e.target.value) }} />
                                    </div>

                                    <div className={styles.input_field}>
                                        <p>
                                            shooting:
                                        </p>
                                        <input type="text" placeholder="shooting"
                                            onChange={(e) => { setShooting(e.target.value) }} />
                                    </div>

                                    <div className={styles.input_field}>
                                        <p>
                                            pass :
                                        </p>
                                        <input type="text" placeholder="Pass"
                                            onChange={(e) => { setPass(e.target.value) }} />
                                    </div>

                                    <div className={styles.input_field}>
                                        <p>
                                            agility :
                                        </p>
                                        <input type="text" placeholder="agility"
                                            onChange={(e) => { setAgility(e.target.value) }} />
                                    </div>

                                    <div className={styles.input_field}>
                                        <p>
                                            defence :
                                        </p>
                                        <input type="text" placeholder="defence"
                                            onChange={(e) => { setDefence(e.target.value) }} />
                                    </div>
                                </>

                            }
                            {
                                !isGoalKeeper &&
                                <>
                                    <div className={styles.input_field}>
                                        <p>
                                            reflexes :
                                        </p>
                                        <input type="text" placeholder="reflexes"
                                            onChange={(e) => { setReflexes(e.target.value) }} />
                                    </div>
                                    <div className={styles.input_field}>
                                        <p>
                                            diving :
                                        </p>
                                        <input type="text" placeholder="diving"
                                            onChange={(e) => { setDiving(e.target.value) }} />
                                    </div>
                                    <div className={styles.input_field}>
                                        <p>
                                            positioning :
                                        </p>
                                        <input type="text" placeholder="positioning"
                                            onChange={(e) => { setPositiong(e.target.value) }} />
                                    </div>
                                    <div className={styles.input_field}>
                                        <p>
                                            handling :
                                        </p>
                                        <input type="text" placeholder="handling"
                                            onChange={(e) => { setHandling(e.target.value) }} />
                                    </div>
                                    <div className={styles.input_field}>
                                        <p>
                                            kicking :
                                        </p>
                                        <input type="text" placeholder="kicking"
                                            onChange={(e) => { setKicking(e.target.value) }} />
                                    </div>

                                </>
                            }

                            <div className={styles.input_field}>
                                <p>
                                    physical:
                                </p>
                                <input type="text" placeholder="physical"
                                    onChange={(e) => { setPhysical(e.target.value) }} />
                            </div>
                        </div>
                        <div className={styles.suggestion}>

                            <div className={styles.suggestion_list}>
                                <div className={styles.add_player_button_container}>
                                    <div className={styles.add_player_button} onClick={() => setIsGoalKeeper(!isGoalKeeper)}>
                                        {
                                            isGoalKeeper ? "player is a goalkeeper" : "player is not a goalkeeper"
                                        }
                                    </div>
                                </div>
                                <div className={styles.add_player_button_container}>
                                    <div className={styles.add_player_button} onClick={async () => {

                                        await executioner(Query.addPlayer(uuid(), playerName, position, nation, club, league, season, weight, height, strong_foot, weak_foot, SM, SB, ST, pace, shooting, pass, agility, defence,
                                            physical, reflexes, diving, positioning, handling, kicking), "SEND");
                                        location.reload();
                                    }}>
                                        add player
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            }
            {
                (stage === STAGE.STAGE2) &&
                <div className={styles.search_container}>
                    <input type="text" placeholder="search player to update"
                        onChange={(e) => { handleSearch(e) }} />
                </div>
            }
            {
                (stage === STAGE.STAGE2) &&
                <div className={styles.search_results}>
                    {
                        filteredPlayers.map((current, index) =>
                            <div key={current.player_name} className={styles.search_result} onClick={() => { router.push(`/update-player-card/${current.player_id}`) }}>
                                <div className={styles.result_part}>
                                    <div className={styles.rating}>{getAverage(current).toFixed(0)}</div>
                                    <div className={styles.league}>{"season " + current.season}</div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.player_name}> {current.player_name} </div>
                                </div>

                                <div className={styles.result_part}>
                                    <div className={styles.league}> {current.league} </div>
                                    <div className={styles.club}> {current.club} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.nation}> {current.nation} </div>
                                </div>
                            </div>
                        )
                    }
                </div>

            }
            {
                (stage === STAGE.STAGE3) &&
                <div className={styles.stage}>
                    <div className={styles.subscribed_users}>
                        {
                            users.map((current, index) =>
                                <div className={styles.subscribed_user}>
                                    <div>
                                        <h3>
                                            User Name :
                                        </h3>
                                        <p>
                                            {current.user_name}
                                        </p>
                                    </div>
                                    <div>
                                        <h3>
                                            Email :
                                        </h3>
                                        <p>
                                            {current.email}
                                        </p>
                                    </div>
                                    <div>

                                        <h3>
                                            Bank Name :
                                        </h3>
                                        <p>
                                            {current.bank_name}
                                        </p>

                                    </div>
                                    <div>

                                        <h3>
                                            account no:
                                        </h3>
                                        <p>
                                            {current.account_no}

                                        </p>

                                    </div>
                                    <div>
                                        <h3>
                                            transaction no:
                                        </h3>
                                        <p>
                                            {current.transaction_code}
                                        </p>
                                    </div>
                                </div>
                            )
                        }
                    </div>
                </div>
            }

        </div>
    )
}

export default Admin