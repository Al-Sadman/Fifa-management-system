import React from 'react'
import database from '../database'
import styles from '../../styles/Compare.module.css'
import { useRouter } from 'next/router'
import { useState } from 'react'
import executioner from '../../Backend/executioner'
import Query from '../../Backend/Queries'

const squads_ind = ({ squad }) => {
    const router = useRouter();

    const player1 = squad.main_players[0];
    const player2 = squad.main_players[1];
    const player3 = squad.main_players[2];
    const player4 = squad.main_players[3];
    const player5 = squad.main_players[4];
    const player6 = squad.main_players[5];
    const player7 = squad.main_players[6];
    const player8 = squad.main_players[7];
    const player9 = squad.main_players[8];
    const player10 = squad.main_players[9];
    const player11 = squad.main_players[10];
    const sub1 = squad.sub_players[0];
    const sub2 = squad.sub_players[1];
    const sub3 = squad.sub_players[2];
    const sub4 = squad.sub_players[3];
    const sub5 = squad.sub_players[4];
    const sub6 = squad.sub_players[5];
    const sub7 = squad.sub_players[6];


    function getAverage(player) {
        if (!player) return;
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }


    return (

        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/squad') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/draft') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>


            {
                <div className={styles.result_part}>
                    <div className={styles.rating}>{"Squad name : " + squad.name}</div>
                </div>
            }
            {
                <div className={styles.result_part}>
                    <div className={styles.rating} style={{ cursor: "pointer" }}
                        onClick={async () => {
                            await executioner(Query.deleteSquad(squad.id), "SEND");
                            router.push('../squad');
                        }}
                    >{"delete Squad"}</div>
                </div>
            }


            {
                <div className={styles.result_part}>
                    <div className={styles.rating}>{"Squad average rating : " + "10"}</div>
                    <div className={styles.rating}> {"squad chemistry : " + ((Math.random() * 15) + 80).toFixed(0) + "%"} </div>
                </div>
            }


            {


                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"st"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player1)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player1?.player_name} </div>
                        </div>

                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player1?.search_result !== undefined) && "season : " + player1?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player1?.league} </div>
                            <div className={styles.club}> {player1?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player1?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"st"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player2)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player2?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player2?.search_result !== undefined) && "season : " + player2?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player2?.league} </div>
                            <div className={styles.club}> {player2?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player2?.nation} </div>
                        </div>
                    </div>
                </div>

            }

            {



                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"lm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player3)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player3?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player3?.search_result !== undefined) && "season : " + player3?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player3?.league} </div>
                            <div className={styles.club}> {player3?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player3?.nation} </div>
                        </div>
                    </div>



                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player4)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player4?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player4?.search_result !== undefined) && "season : " + player4?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player4?.league} </div>
                            <div className={styles.club}> {player4?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player4?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player5)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {(player5?.search_result !== undefined) && player5?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player5?.search_result !== undefined) && "season : " + player5?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player5?.league} </div>
                            <div className={styles.club}> {player5?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player5?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"rm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player6)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player6?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> { (player6?.search_result !== undefined) && "season : " + player6?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player6?.league} </div>
                            <div className={styles.club}> {player6?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player6?.nation} </div>
                        </div>
                    </div>

                </div>

            }


            {


                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"lb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player7)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player7?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player7?.search_result !== undefined) && "season : " + player7?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player7?.league} </div>
                            <div className={styles.club}> {player7?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player7?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player8)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player8?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player8?.search_result !== undefined) && "season : " + player8?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player8?.league} </div>
                            <div className={styles.club}> {player8?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player8?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player9)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player9?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player9?.search_result !== undefined) && "season : " + player9?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player9?.league} </div>
                            <div className={styles.club}> {player9?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player9?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"rb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player10)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player10?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player10?.season !== undefined) && "season : " + player10?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player10?.league} </div>
                            <div className={styles.club}> {player10?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player10?.nation} </div>
                        </div>
                    </div>

                </div>

            }

            {

                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {

                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"gk"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player11)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player11?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.player_name}> {(player11?.search_result !== undefined) && "season : " + player11?.season} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player11?.league} </div>
                            <div className={styles.club}> {player11?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player11?.nation} </div>
                        </div>
                    </div>
                </div>

            }


            {

                <div className={styles.select_player_container}>

                    {
                        sub1 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub1)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub1?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub1?.search_result !== undefined) && "season : " + sub1?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub1?.league} </div>
                                <div className={styles.club}> {sub1?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub1?.nation} </div>
                            </div>
                        </div>
                    }
                    {
                        sub2 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub2)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub2?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub2?.search_result !== undefined) && "season : " + sub2?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub2?.league} </div>
                                <div className={styles.club}> {sub2?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub3?.nation} </div>
                            </div>
                        </div>
                    }
                    {
                        sub3 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub3)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub3?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub3?.search_result !== undefined) && "season : " + sub3?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub3?.league} </div>
                                <div className={styles.club}> {sub3?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub3?.nation} </div>
                            </div>
                        </div>
                    }
                    {
                        sub4 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub4)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub4?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub4?.search_result !== undefined) && "season : " + sub4?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub4?.league} </div>
                                <div className={styles.club}> {sub4?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub4?.nation} </div>
                            </div>
                        </div>
                    }

                </div>

            }




            {

                <div className={styles.select_player_container}>

                    {
                        sub5 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub5)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub5?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub5?.search_result !== undefined) && "season : " + sub5?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub5?.league} </div>
                                <div className={styles.club}> {sub5?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub5?.nation} </div>
                            </div>
                        </div>
                    }
                    {
                        sub6 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub6)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub6?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub6?.search_result !== undefined) && "season : " + sub6?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub6?.league} </div>
                                <div className={styles.club}> {sub6?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub6?.nation} </div>
                            </div>
                        </div>
                    }
                    {
                        sub7 &&
                        <div className={styles.search_result} onClick={() => { }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{"substitute"}</div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(sub7)?.toFixed(0)}</div>
                                <div className={styles.player_name}> {sub7?.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.player_name}> {(sub7?.search_result !== undefined) && "season : " + sub7?.season} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {sub7?.league} </div>
                                <div className={styles.club}> {sub7?.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {sub7?.nation} </div>
                            </div>
                        </div>
                    }

                </div>

            }


        </div>

    )
}


// gets the props for the current slug
export const getServerSideProps = async pageContext => {
    const notApplicable =
    {
        notFound: true
    }
    const squad_to_find = pageContext.query.squad_id;
    if (!squad_to_find) {
        return notApplicable;
    }
    else {


        let squads_DB;
        squads_DB = (await executioner(Query.getSquads(), "RETRIEVE"))?.data.data;
        console.log(squads_DB);


        let squads = [];
        for (let i = 0; i < squads_DB.length; i++) {
            // console.log();
            let squad = JSON.parse(squads_DB[i].squad);
            squads = [...squads, squad];

        }

        let squad = squads.find(current => current.id === squad_to_find);
        return { props: { squad } };
    }
};

export default squads_ind