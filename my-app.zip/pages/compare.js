import Head from 'next/head'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import styles from '../styles/Compare.module.css'
import database from './database'
import ProgressBar from 'react-percent-bar';
import executioner from '../Backend/executioner'
import Query from '../Backend/Queries'



const filter = () => {

    const SELECT =
    {
        NONE: 'NONE',
        P1: 'p1',
        P2: 'p2',
    }
    const router = useRouter();
    const [text, setText] = useState("");
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState([]);
    const [isGoalKeeper, setIsGoalKeeper] = useState(false);
    const [showComparison, setShowComparison] = useState(false);
    const [selected, setSelected] = useState(SELECT.NONE);
    const [player1, setPlayer1] = useState(null);
    const [player2, setPlayer2] = useState(null);



    useEffect(() => {
        async function run() {
            let players;
            players = await executioner(Query.getPlayers(), "RETRIEVE");
            setAllPlayers(players.data?.data);
            setFilteredPlayers(players?.data?.data);
        }
        run();
    }, [])
   
    function getAverage(player) {
        if(!player) return;
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }


    let handleSearch = (event) => {
        let keyword = event?.target?.value;
        setText(keyword);
        let result = [];
        for (let i = 0; i < allPlayers.length; i++) {
            if (allPlayers[i].player_name.toLowerCase().includes(keyword.toLowerCase()))
                result = [...result, allPlayers[i]];
        }
        setFilteredPlayers(result);
    }



    return (
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/squad') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/draft') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>
            {
                ((selected === SELECT.NONE) && player1 && player2) &&
                <div className={styles.result_part}>
                    <div className={styles.rating} style={{ cursor: "pointer" }} onClick={() => { setShowComparison(true) }}>Compare</div>
                </div>

            }

            <div className={styles.select_player_container}>

                <div className={styles.search_result} onClick={() => {
                    setSelected(SELECT.P1);
                    setShowComparison(false);
                }}>
                    <div className={styles.result_part}>
                        <div className={styles.rating} style={{ color: "#309a13" }}>{"Player 1"}</div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.rating}>{getAverage(player1)?.toFixed(0)}</div>
                        {
                            player1?.season &&
                            <div className={styles.player_name}> {"season : " + player1?.season} </div>
                        }
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.player_name}> {player1?.player_name} </div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.league}> {player1?.league} </div>
                        <div className={styles.club}> {player1?.club} </div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.nation}> {player1?.nation} </div>
                    </div>
                </div>

                <div className={styles.search_result} onClick={() => {
                    setSelected(SELECT.P2);
                    setShowComparison(false);
                }}>
                    <div className={styles.result_part}>
                        <div className={styles.rating} style={{ color: "#c51c1c" }}>{"Player 2"}</div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.rating}>{getAverage(player2)?.toFixed(0)}</div>
                        {
                            player2?.season &&
                            <div className={styles.player_name}> {"season : " + player2?.season} </div>
                        }
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.player_name}> {player2?.player_name} </div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.league}> {player2?.league} </div>
                        <div className={styles.club}> {player2?.club} </div>
                    </div>
                    <div className={styles.result_part}>
                        <div className={styles.nation}> {player2?.nation} </div>
                    </div>
                </div>
            </div>
            {
                (selected !== SELECT.NONE) &&
                <div className={styles.search_container}>
                    <input type="text" placeholder={(SELECT.P1 === selected) ? "Search Player 1" : "Search Player 2"}
                        onChange={(e) => { handleSearch(e) }} />
                </div>
            }
            {
                (selected !== SELECT.NONE) &&
                <div className={styles.search_results}>
                    {
                        filteredPlayers.map((current, index) =>
                            <div key={current.player_name} className={styles.search_result} onClick={() => {
                                if (selected === SELECT.P1) setPlayer1(current);
                                else if (selected === SELECT.P2) setPlayer2(current);
                                setSelected(SELECT.NONE);
                            }}>
                                <div className={styles.result_part}>
                                    <div className={styles.rating}>{getAverage(current).toFixed(0)}</div>
                                    <div className={styles.league}>{"season " + current.season}</div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.player_name}> {current.player_name} </div>
                                </div>

                                <div className={styles.result_part}>
                                    <div className={styles.league}> {current.league} </div>
                                    <div className={styles.club}> {current.club} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.nation}> {current.nation} </div>
                                </div>
                            </div>
                        )
                    }
                </div>

            }


            {
                showComparison &&
                (player1.position !== 'gk' && player2.position !== 'gk') &&
                <div className={styles.points}>
                    <div> </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 rating : " + getAverage(player1).toFixed(0)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={getAverage(player1)} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 rating : " + getAverage(player2).toFixed(0)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={getAverage(player2)} />
                        </div>
                    </div>

                    <div> </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 pace : " + player1.pace}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.pace} />
                        </div>

                        <div className={styles.point_name}>
                            {"Player 2 pace : " + player2.pace}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.pace} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 shooting : " + player1.shooting}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.shooting} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 shooting : " + player2.shooting}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.shooting} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 pass : " + player1.pass}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.pass} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 pass : " + player2.pass}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.pass} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 agility : " + player1.agility}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.agility} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 agility : " + player2.agility}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.agility} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 defence : " + player1.defence}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.defence} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 defence : " + player2.defence}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.defence} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 physical : " + player1.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.physical} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 physical : " + player2.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={player2.physical} />
                        </div>
                    </div>

                </div>
            }
            {
                showComparison &&
                ((player1.position !== 'gk' && player2.position === 'gk') || (player1.position === 'gk' && player2.position !== 'gk')) &&

                <div className={styles.points}>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 rating : " + getAverage(player1)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={getAverage(player1)} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 rating : " + getAverage(player2)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={getAverage(player2)} />
                        </div>
                    </div>
                    <div> </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 physical : " + player1.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.physical} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 physical : " + player2.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.physical} />
                        </div>
                    </div>
                </div>

            }


            {/* {
                (player_info.position === 'gk') &&

                <div className={styles.points}>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"reflexes : " + player_info.reflexes}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.reflexes} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"diving : " + player_info.diving}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.diving} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"positioning : " + player_info.positioning}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.positioning} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"handling : " + player_info.handling}

                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.handling} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"kicking : " + player_info.kicking}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.kicking} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"physical : " + player_info.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" colorShift={true} fillColor="#999999" percent={player_info.physical} />
                        </div>
                    </div>

                </div>
            } */}

            {
                showComparison &&
                (player1.position === 'gk' && player2.position === 'gk') &&

                <div className={styles.points}>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 rating : " + getAverage(player1)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={getAverage(player1)} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 rating : " + getAverage(player2)}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#c51c1c" percent={getAverage(player2)} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 reflexes : " + player1.reflexes}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.reflexes} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 reflexes : " + player2.reflexes}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.reflexes} />
                        </div>
                    </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 diving : " + player1.diving}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.diving} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 diving : " + player2.diving}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.diving} />
                        </div>
                    </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 positioning : " + player1.positioning}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.positioning} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 positioning : " + player2.positioning}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.positioning} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 handling : " + player1.handling}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.handling} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 handling : " + player2.handling}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.handling} />
                        </div>
                    </div>
                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 kicking : " + player1.kicking}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.kicking} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 kicking : " + player2.kicking}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.kicking} />
                        </div>
                    </div>

                    <div className={styles.point_holder}>
                        <div className={styles.point_name}>
                            {"Player 1 physical : " + player1.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="#309a13" percent={player1.physical} />
                        </div>
                        <div className={styles.point_name}>
                            {"Player 2 physical : " + player2.physical}
                        </div>
                        <div className={styles.point_bar}>
                            <ProgressBar width="80%" fillColor="red" percent={player2.physical} />
                        </div>
                    </div>
                </div>

            }

        </div >
    )
}

export default filter