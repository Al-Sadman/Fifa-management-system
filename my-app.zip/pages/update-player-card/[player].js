import React from 'react'
import database from '../database'
import styles from '../../styles/Admin.module.css'
import { useRouter } from 'next/router'
import { useState } from 'react'
import executioner from '../../Backend/executioner'
import Query from '../../Backend/Queries'
import {v4 as uuid} from 'uuid'

const player = ({ player_info }) => {
    const router = useRouter();


    const [player, setPlayer] = useState(player_info);
    return (

        <div className={styles.container}>

            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    Fifa Buddy
                </div>
                <div className={styles.navbottom}>


                    <div className={styles.navbottom_link} onClick={() => { router.push('/admin') }}>
                        admin panel
                    </div>

                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>

            <div className={styles.stage}>
                <div className={styles.add_player}>
                    <div className={styles.input_fields}>


                        <div className={styles.input_field}>
                            <p>
                                Player Name :
                            </p>
                            <input type="text" value={player.player_name} placeholder="Player name"
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.player_name = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                nation :
                            </p>
                            <input type="text" placeholder="nation" value={player.nation}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.nation = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                club :
                            </p>
                            <input type="text" placeholder="club" value={player.club}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.club = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>

                        <div className={styles.input_field}>
                            <p>
                                League :
                            </p>
                            <input type="text" placeholder="league" value={player.league}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.league = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                season :
                            </p>
                            <input type="text" placeholder="season" value={player.season}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.season = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                weight :
                            </p>
                            <input type="text" placeholder="weight" value={player.weight}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.weight = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                height :
                            </p>
                            <input type="text" placeholder="height" value={player.height}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.height = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                strong foot :
                            </p>
                            <input type="text" placeholder="strong foot" value={player.strong_foot}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.strong_foot = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                weak foot :
                            </p>
                            <input type="text" placeholder="weak foot" value={player.weak_foot}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.weak_foot = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                skill move:
                            </p>
                            <input type="text" placeholder="skill move" value={player.skill_move}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.skill_move = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                skill boost :
                            </p>
                            <input type="text" placeholder="skill boost" value={player.skill_boost}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.skill_boost = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                        <div className={styles.input_field}>
                            <p>
                                special trait :
                            </p>
                            <input type="text" placeholder="special trait" value={player.special_trait}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.special_trait = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>

                        {
                            (player_info.position !== 'gk') &&
                            <>

                                <div className={styles.input_field}>
                                    <p>
                                        pace :
                                    </p>
                                    <input type="text" placeholder="Pace" value={player.pace}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.pace = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>

                                <div className={styles.input_field}>
                                    <p>
                                        shooting:
                                    </p>
                                    <input type="text" placeholder="shooting" value={player.shooting}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.shooting = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>

                                <div className={styles.input_field}>
                                    <p>
                                        pass :
                                    </p>
                                    <input type="text" placeholder="Pass" value={player.pass}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.pass = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>

                                <div className={styles.input_field}>
                                    <p>
                                        agility :
                                    </p>
                                    <input type="text" placeholder="agility" value={player.agility}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.agility = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>

                                <div className={styles.input_field}>
                                    <p>
                                        defence :
                                    </p>
                                    <input type="text" placeholder="defence" value={player.defence}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.defence = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>
                            </>

                        }
                        {
                            (player_info.position === 'gk') &&

                            <>
                                <div className={styles.input_field}>
                                    <p>
                                        reflexes :
                                    </p>
                                    <input type="text" placeholder="reflexes" value={player.reflexes}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.reflexes = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>
                                <div className={styles.input_field}>
                                    <p>
                                        diving :
                                    </p>
                                    <input type="text" placeholder="diving" value={player.diving}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.diving = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>
                                <div className={styles.input_field}>
                                    <p>
                                        positioning :
                                    </p>
                                    <input type="text" placeholder="positioning" value={player.positioning}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.positioning = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>
                                <div className={styles.input_field}>
                                    <p>
                                        handling :
                                    </p>
                                    <input type="text" placeholder="handling" value={player.handling}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.handling = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>
                                <div className={styles.input_field}>
                                    <p>
                                        kicking :
                                    </p>
                                    <input type="text" placeholder="kicking" value={player.kicking}
                                        onChange={(e) => {
                                            let updated = { ...player };
                                            updated.kicking = e.target.value;
                                            setPlayer(updated);
                                        }} />
                                </div>

                            </>
                        }

                        <div className={styles.input_field}>
                            <p>
                                physical:
                            </p>
                            <input type="text" placeholder="physical" value={player.physical}
                                onChange={(e) => {
                                    let updated = { ...player };
                                    updated.physical = e.target.value;
                                    setPlayer(updated);
                                }} />
                        </div>
                    </div>
                    <div className={styles.suggestion}>

                        <div className={styles.suggestion_list}>
                            <div className={styles.add_player_button_container}>
                                <div className={styles.add_player_button} onClick={async () => {
                                    
                                    // first delete the information about the player's old card
                                    await executioner(Query.deletePlayer(player.player_id), "SEND");

                                    // add the player with the same id and newer information
                                    await executioner(Query.addPlayer(player.player_id, player.player_name, player.position, player.nation, player.club,
                                        player.league, player.season, player.weight, player.height, player.strong_foot, player.weak_foot, 
                                        player.skill_move, player.skill_boost, player.special_trait,
                                        player.pace, player.shooting, player.pass, player.agility, player.defence,
                                        player.physical, player.reflexes, player.diving, player.positioning, player.handling, player.kicking), "SEND");
                                        router.push('/admin');
                                }}>
                                    update player
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    )
}


// gets the props for the current slug
export const getServerSideProps = async pageContext => {
    const notApplicable =
    {
        notFound: true
    }
    const player = pageContext.query.player;
    console.log(player);
    if (!player) {
        return notApplicable;
    }
    else {
        let players;
        players = await executioner(Query.getPlayers(), "RETRIEVE");
        let player_info = players.data.data.find(current => current.player_id === player);
        return { props: { player_info } };
    }
};

export default player