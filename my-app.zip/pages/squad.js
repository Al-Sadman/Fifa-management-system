import Head from 'next/head'
import Image from 'next/image'
import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import styles from '../styles/Compare.module.css'
import database from './database'
import ProgressBar from 'react-percent-bar';
import executioner from '../Backend/executioner'
import Query from '../Backend/Queries'
const escapeString = require('sql-string-escape')
import { v4 as uuid } from 'uuid'

const filter = () => {

    const FORMATION = [
        "4-4-2",
        "4-3-3",
        "4-5-1",
        "3-4-3"
    ]

    const SELECT =
    {
        NONE: 'NONE',
        P1: 'p1',
        P2: 'p2',
        P3: 'p3',
        P4: 'p4',
        P5: 'p5',
        P6: 'p6',
        P7: 'p7',
        P8: 'p8',
        P9: 'p9',
        P10: 'p10',
        P11: 'p11',
        s1: 's1',
        s2: 's2',
        s3: 's3',
        s4: 's4',
        s5: 's5',
        s6: 's6',
        s7: 's7',
    }
    const router = useRouter();
    const [text, setText] = useState("");
    const [squadName, setSquadName] = useState("");
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState([]);
    const [isGoalKeeper, setIsGoalKeeper] = useState(false);
    const [showComparison, setShowComparison] = useState(false);
    const [selected, setSelected] = useState(SELECT.NONE);
    const [player1, setPlayer1] = useState(null);
    const [player2, setPlayer2] = useState(null);
    const [player3, setPlayer3] = useState(null);
    const [player4, setPlayer4] = useState(null);
    const [player5, setPlayer5] = useState(null);
    const [player6, setPlayer6] = useState(null);
    const [player7, setPlayer7] = useState(null);
    const [player8, setPlayer8] = useState(null);
    const [player9, setPlayer9] = useState(null);
    const [player10, setPlayer10] = useState(null);
    const [player11, setPlayer11] = useState(null);
    const [subPlayer1, setSubPlayer1] = useState(null);
    const [subPlayer2, setSubPlayer2] = useState(null);
    const [subPlayer3, setSubPlayer3] = useState(null);
    const [subPlayer4, setSubPlayer4] = useState(null);
    const [subPlayer5, setSubPlayer5] = useState(null);
    const [subPlayer6, setSubPlayer6] = useState(null);
    const [subPlayer7, setSubPlayer7] = useState(null);
    const [addSubPlayer, setAddSubPlayer] = useState(false);
    const [formation, setFormation] = useState(FORMATION[0]);
    const [showFormation, setShowFormation] = useState(false);

    const [averageRating, setAverageRating] = useState(0);
    const [averageChemistry, setAverageChemistry] = useState(0);


    useEffect(() => {

        async function run() {
            let players;
            players = await executioner(Query.getPlayers(), "RETRIEVE");
            setAllPlayers(players.data?.data);
            setFilteredPlayers(players?.data?.data);
        }
        run();

    }, [])

    function getAverage(player) {
        if (!player) return;
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }

    let handleSearch = (event) => {
        let keyword = event?.target?.value;
        setText(keyword);
        let result = [];
        for (let i = 0; i < allPlayers.length; i++) {
            if (allPlayers[i].player_name.toLowerCase().includes(keyword.toLowerCase()))
                result = [...result, allPlayers[i]];
        }
        setFilteredPlayers(result);
    }
    let handleSquadName = (event) => {
        let keyword = event?.target?.value;
        setSquadName(keyword);
    }

    useEffect(() => {

    }, [player1, player2, player3, player4, player5, player6, player7, player8, player9, player10, player11])




    return (
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    <p style={{ cursor: "pointer" }} onClick={() => { router.push('/home') }}>
                        Fifa Buddy : home
                    </p>
                </div>
                <div className={styles.navbottom}>


                    <div className={styles.navbottom_link} onClick={() => { router.push('/compare') }}>
                        compare
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/draft') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>

            {
                (selected !== SELECT.NONE) &&
                <div className={styles.search_container}>
                    <input type="text" placeholder={`search ${selected}`}
                        onChange={(e) => { handleSearch(e) }} />
                </div>
            }

            {
                (selected === SELECT.NONE) &&
                <div className={styles.search_container}>
                    <input type="text" value={squadName} placeholder={`enter squad name`}
                        onChange={(e) => { handleSquadName(e) }} />
                </div>
            }



            {
                (selected === SELECT.NONE) &&
                <div className={styles.result_part}>
                    <div className={styles.rating} style={{ cursor: "pointer" }} onClick={() => { setShowFormation(!showFormation) }}>
                        {"formation : " + formation}
                    </div>
                </div>
            }
            {
                (selected === SELECT.NONE) && showFormation &&
                <div>
                    {
                        FORMATION.map((current, index) =>
                            <div className={styles.rating} style={{
                                width: "max-content", margin: "10px", padding: "10px",
                                marginLeft: "auto", marginRight: "auto", borderRadius: "10px",
                                borderBottom: "1px solid black",
                                cursor: "pointer",
                            }} onClick={() => {
                                setFormation(FORMATION[index]);
                                setShowFormation(false);
                            }}>
                                {current}
                            </div>
                        )
                    }
                </div>
            }

            {
                (selected === SELECT.NONE) &&
                <div className={styles.result_part}>
                    <div className={styles.rating}>{"Squad average rating : " + averageRating}</div>
                    <div className={styles.rating}> {"squad chemistry : " + averageChemistry + "%"} </div>
                </div>
            }




            {
                (selected !== SELECT.NONE) &&
                <div className={styles.search_results}>
                    {
                        filteredPlayers.map((current, index) =>
                            <div key={current.player_name} className={styles.search_result} onClick={() => {
                                if (selected === SELECT.P1) setPlayer1(current);
                                else if (selected === SELECT.P2) setPlayer2(current);
                                else if (selected === SELECT.P3) setPlayer3(current);
                                else if (selected === SELECT.P4) setPlayer4(current);
                                else if (selected === SELECT.P5) setPlayer5(current);
                                else if (selected === SELECT.P6) setPlayer6(current);
                                else if (selected === SELECT.P7) setPlayer7(current);
                                else if (selected === SELECT.P8) setPlayer8(current);
                                else if (selected === SELECT.P9) setPlayer9(current);
                                else if (selected === SELECT.P10) setPlayer10(current);
                                else if (selected === SELECT.P11) setPlayer11(current);
                                else if (selected === SELECT.s1) setSubPlayer1(current);
                                else if (selected === SELECT.s2) setSubPlayer2(current);
                                else if (selected === SELECT.s3) setSubPlayer3(current);
                                else if (selected === SELECT.s4) setSubPlayer4(current);
                                else if (selected === SELECT.s5) setSubPlayer5(current);
                                else if (selected === SELECT.s6) setSubPlayer6(current);
                                else if (selected === SELECT.s7) setSubPlayer7(current);
                                setSelected(SELECT.NONE);
                            }}>
                                <div className={styles.result_part}>
                                    <div className={styles.rating}>{getAverage(current).toFixed(0)}</div>
                                    <div className={styles.player_name}> {current.player_name} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.league}> {current.league} </div>
                                    <div className={styles.club}> {current.club} </div>
                                </div>
                                <div className={styles.result_part}>
                                    <div className={styles.nation}> {current.nation} </div>
                                </div>
                            </div>
                        )
                    }
                </div>

            }


            {
                (selected === SELECT.NONE) &&

                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P1);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"st"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player1)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player1?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player1?.league} </div>
                            <div className={styles.club}> {player1?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player1?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P2);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"st"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player2)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player2?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player2?.league} </div>
                            <div className={styles.club}> {player2?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player2?.nation} </div>
                        </div>
                    </div>
                </div>

            }

            {
                (selected === SELECT.NONE) &&


                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P3);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"lm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player3)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player3?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player3?.league} </div>
                            <div className={styles.club}> {player3?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player3?.nation} </div>
                        </div>
                    </div>



                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P4);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player4)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player4?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player4?.league} </div>
                            <div className={styles.club}> {player4?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player4?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P5);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player5)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player5?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player5?.league} </div>
                            <div className={styles.club}> {player5?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player5?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P6);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"rm"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player6)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player6?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player6?.league} </div>
                            <div className={styles.club}> {player6?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player6?.nation} </div>
                        </div>
                    </div>

                </div>

            }


            {
                (selected === SELECT.NONE) &&

                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P7);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"lb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player7)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player7?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player7?.league} </div>
                            <div className={styles.club}> {player7?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player7?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P8);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player8)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player8?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player8?.league} </div>
                            <div className={styles.club}> {player8?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player8?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P9);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"cb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player9)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player9?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player9?.league} </div>
                            <div className={styles.club}> {player9?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player9?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P10);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"rb"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player10)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player10?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player10?.league} </div>
                            <div className={styles.club}> {player10?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player10?.nation} </div>
                        </div>
                    </div>

                </div>

            }

            {
                (selected === SELECT.NONE) &&

                <div className={styles.select_player_container}>
                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.P11);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"gk"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(player11)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {player11?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {player11?.league} </div>
                            <div className={styles.club}> {player11?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {player11?.nation} </div>
                        </div>
                    </div>
                </div>

            }

            {
                // (player1 && player2 && player3 && player4 && player5 && player6 && player7 && player8 && player9 && player10 && player11) &&
                (selected === SELECT.NONE) &&
                <div className={styles.result_part}>
                    <div className={styles.rating} style={{ cursor: "pointer" }} onClick={() => {
                        setAddSubPlayer(!addSubPlayer);
                    }}>add substitute player</div>
                </div>

            }
            {
                (selected === SELECT.NONE) && addSubPlayer &&

                <div className={styles.select_player_container}>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s1);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer1)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer1?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer1?.league} </div>
                            <div className={styles.club}> {subPlayer1?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer1?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s2);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer2)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer2?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer2?.league} </div>
                            <div className={styles.club}> {subPlayer2?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer2?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s3);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer3)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer3?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer3?.league} </div>
                            <div className={styles.club}> {subPlayer3?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer3?.nation} </div>
                        </div>
                    </div>


                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s4);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer4)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer4?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer4?.league} </div>
                            <div className={styles.club}> {subPlayer4?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer4?.nation} </div>
                        </div>
                    </div>


                </div>

            }
            {
                (selected === SELECT.NONE) && addSubPlayer &&

                <div className={styles.select_player_container}>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s5);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer5)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer5?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer5?.league} </div>
                            <div className={styles.club}> {subPlayer5?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer5?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s6);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer6)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer6?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer6?.league} </div>
                            <div className={styles.club}> {subPlayer6?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer6?.nation} </div>
                        </div>
                    </div>

                    <div className={styles.search_result} onClick={() => {
                        setSelected(SELECT.s7);
                        setShowComparison(false);
                    }}>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{"substitue"}</div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.rating}>{getAverage(subPlayer7)?.toFixed(0)}</div>
                            <div className={styles.player_name}> {subPlayer7?.player_name} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.league}> {subPlayer7?.league} </div>
                            <div className={styles.club}> {subPlayer7?.club} </div>
                        </div>
                        <div className={styles.result_part}>
                            <div className={styles.nation}> {subPlayer7?.nation} </div>
                        </div>
                    </div>
                </div>

            }
            {
                // (player1 && player2 && player3 && player4 && player5 && player6 && player7 && player8 && player9 && player10 && player11) &&
                (selected === SELECT.NONE) &&
                <div className={styles.result_part}>
                    <div className={styles.rating} style={{ cursor: "pointer" }} onClick={async () => {
                        let ID = uuid();
                        // squad is a json that has arrays of array 
                        // the json including the player array will be saved in the sql database
                        let squad = {
                            id: ID,
                            user_id: "1",
                            name: squadName,
                            formation: formation,
                            sub_players: [subPlayer1, subPlayer2, subPlayer3, subPlayer4, subPlayer5, subPlayer6, subPlayer7],
                            main_players: [player1, player2, player3, player4, player5, player6, player7, player8, player9, player10, player11],
                        };
                        // console.log(escapeString(JSON.stringify(squad)));
                        await executioner(Query.addSquad(ID, escapeString(JSON.stringify(squad))), "SEND");
                        setSquadName("");
                        setPlayer1(null);
                        setPlayer2(null);
                        setPlayer3(null);
                        setPlayer4(null);
                        setPlayer5(null);
                        setPlayer6(null);
                        setPlayer7(null);
                        setPlayer8(null);
                        setPlayer9(null);
                        setPlayer10(null);
                        setPlayer11(null);
                        setSubPlayer1(null);
                        setSubPlayer2(null);
                        setSubPlayer3(null);
                        setSubPlayer4(null);
                        setSubPlayer5(null);
                        setSubPlayer6(null);
                        setSubPlayer7(null);
                        router.push('/draft');
                    }}>Save squad</div>
                </div>

            }
            {
                showComparison &&
                <p>
                    showComparison
                </p>
            }
        </div >
    )
}

export default filter