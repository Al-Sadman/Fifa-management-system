import { useRouter } from 'next/router'
import { useEffect, useState } from 'react'
import executioner from '../Backend/executioner'
import Query from '../Backend/Queries'
import styles from '../styles/Home.module.css'
import database from './database'

export default function Home() {
    const router = useRouter();
    const [showSeason, setShowSeason] = useState(false);
    const [text, setText] = useState("");
    const [countryText, setCountryText] = useState("");
    const [clubText, setClubText] = useState("");
    const [seasonText, setSeasonText] = useState("");
    const [leagueText, setLeagueText] = useState("");
    const [allPlayers, setAllPlayers] = useState([]);
    const [filteredPlayers, setFilteredPlayers] = useState(null);

    const [isGoalKeeper, setIsGoalKeeper] = useState(false);



    useEffect(() => {

        async function run() {
            let players;
            players = await executioner(Query.getPlayers(), "RETRIEVE");
            setAllPlayers(players.data?.data);
            setFilteredPlayers(players?.data?.data);
        }
        run();

    }, [])



    useEffect(() => {
        if (!filteredPlayers) return;
        let result = [];
        for (let i = 0; i < allPlayers.length; i++) {


            if ((allPlayers[i].player_name.toLowerCase().includes(text.toLowerCase()) &&
                (allPlayers[i].club.toLowerCase().includes(clubText.toLowerCase()))) &&
                (allPlayers[i].nation.toLowerCase().includes(countryText.toLowerCase())) &&
                (allPlayers[i].season.toLowerCase().includes(seasonText.toLowerCase())) &&
                (allPlayers[i].league.toLowerCase().includes(leagueText.toLowerCase()))
            ) {
                result = [...result, allPlayers[i]];
            }

        }

        setFilteredPlayers(result);

    }, [text, countryText, clubText, seasonText, leagueText])


    function getAverage(player) {
        console.log(player.pace);
        let summation = 0.0;
        if (player.position !== 'gk') {
            summation = summation + parseFloat(player.pace);
            summation = summation + parseFloat(player.shooting);
            summation = summation + parseFloat(player.pass);
            summation = summation + parseFloat(player.agility);
            summation = summation + parseFloat(player.defence);
            summation = summation + parseFloat(player.physical);

        }
        else {
            summation = summation + parseFloat(player.physical);
            summation = summation + parseFloat(player.reflexes);
            summation = summation + parseFloat(player.diving);
            summation = summation + parseFloat(player.positioning);
            summation = summation + parseFloat(player.handling);
            summation = summation + parseFloat(player.kicking);
        }
        return summation / 6.0;
    }


    let handleSearch = (event, search_bar) => {
        let keyword = event?.target?.value;
        if (search_bar === 1) setText(keyword);
        if (search_bar === 2) setCountryText(keyword);
        if (search_bar === 3) setClubText(keyword);
        if (search_bar === 4) setSeasonText(keyword);
        if (search_bar === 5) setLeagueText(keyword);
    }



    return (
        <div className={styles.container}>
            <div className={styles.navbar}>
                <div className={styles.navtop}>
                    Fifa Buddy
                </div>
                <div className={styles.navbottom}>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/squad') }}>
                        squad builder
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/compare') }}>
                        compare
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/draft') }}>
                        draft
                    </div>
                    <div className={styles.navbottom_link} onClick={() => {}}>
                        subscribe
                    </div>
                    <div className={styles.navbottom_link} onClick={() => { router.push('/login') }}>
                        logout
                    </div>
                </div>
            </div>
            {

                <div className={styles.search_container}>
                    <input value={text} type="text" placeholder="search player"
                        onChange={(e) => { handleSearch(e, 1) }} />
                </div>

            }


            <div style={{ display: "flex" }}>
                <div className={styles.search_container}>
                    <input type="text" placeholder="search player by country"
                        onChange={(e) => { handleSearch(e, 2) }} />
                </div>

                <div className={styles.search_container}>
                    <input type="text" placeholder="search player by club"
                        onChange={(e) => { handleSearch(e, 3) }} />
                </div>
                <div className={styles.search_container}>
                    <input type="text" placeholder="search player by season"
                        onChange={(e) => { handleSearch(e, 4) }} />
                </div>
                <div className={styles.search_container}>
                    <input type="text" placeholder="search player by League"
                        onChange={(e) => { handleSearch(e, 5) }} />
                </div>
            </div>


            <div className={styles.search_results}>
                {
                    filteredPlayers?.map((current, index) =>
                        <div key={current.player_id} className={styles.search_result} onClick={() => { router.push(`/player-card/${current.player_id}`) }}>
                            <div className={styles.result_part}>
                                <div className={styles.rating}>{getAverage(current).toFixed(0)}</div>
                                <div className={styles.league}>{"season " + current.season}</div>
                            </div>
                            <div className={styles.result_part}>

                                <div className={styles.player_name}> {current.player_name} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.league}> {current.league} </div>
                                <div className={styles.club}> {current.club} </div>
                            </div>
                            <div className={styles.result_part}>
                                <div className={styles.nation}> {current.nation} </div>
                            </div>
                        </div>
                    )
                }
            </div>


        </div>
    )
}
